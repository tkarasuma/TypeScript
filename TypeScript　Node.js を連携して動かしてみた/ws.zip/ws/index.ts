
import * as fs from "fs"
{
fs.readFile("./test.txt",'utf-8',(err,data)=>{
    console.log(data)
})
}